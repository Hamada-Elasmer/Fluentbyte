/* ============================================================================
 * SparkFlow File Header
 * File: Libraries/AdbLib/Abstractions/IAdbClient.cs
 * Purpose: Library component: IAdbClient.
 * Notes:
 *  - This file is part of the SparkFlow automation platform.
 *  - Comments are intentionally kept in English for consistency across the codebase.
 * ============================================================================ */

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using AdbLib.Models;

namespace AdbLib.Abstractions;

public interface IAdbClient
{
    string AdbExePath { get; }

    void KillServer(int timeoutMs = 12_000);
    void StartServer(int timeoutMs = 20_000);

    IReadOnlyList<AdbDevice> Devices(int timeoutMs = 15_000);

    string Shell(string serial, string shellCommand, int timeoutMs = 30_000);
    string RunRaw(string arguments, int timeoutMs = 30_000);

    Task WaitForDeviceReadyAsync(string serial, CancellationToken ct);

    // Package helpers
    void StartPackageMonkey(string serial, string packageName, int timeoutMs = 30_000);
    void ForceStopPackage(string serial, string packageName, int timeoutMs = 30_000);
    bool IsPackageRunning(string serial, string packageName, int timeoutMs = 15_000);

    // Real launch
    void StartActivity(string serial, string component, int timeoutMs = 30_000);
    string GetTopActivity(string serial, int timeoutMs = 30_000);

    // Screenshot
    byte[] ScreenshotPng(string serial, int timeoutMs = 30_000);
}