/* ============================================================================
 * SparkFlow File Header
 * File: Libraries/AdbLib/Services/AdbClient.cs
 * Purpose: Library component: AdbClient.
 * ============================================================================ */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using AdbLib.Abstractions;
using AdbLib.Exceptions;
using AdbLib.Internal;
using AdbLib.Models;
using AdbLib.Options;

namespace AdbLib.Services;

public sealed class AdbClient : IAdbClient
{
    private readonly AdbOptions _opt;
    public string AdbExePath { get; }

    public AdbClient(IAdbProvisioning provisioning, AdbOptions options)
    {
        _opt = options ?? throw new ArgumentNullException(nameof(options));
        AdbExePath = provisioning.EnsureProvisioned();
    }

    public void KillServer(int timeoutMs = 12_000)
        => _ = RunRaw("kill-server", timeoutMs);

    public void StartServer(int timeoutMs = 20_000)
        => _ = RunRaw("start-server", timeoutMs);

    public IReadOnlyList<AdbDevice> Devices(int timeoutMs = 15_000)
        => ParseDevices(RunRaw("devices -l", timeoutMs));

    public string Shell(string serial, string shellCommand, int timeoutMs = 30_000)
        => RunArgs(new[] { "-s", serial, "shell", shellCommand }, timeoutMs);

    public string RunRaw(string arguments, int timeoutMs = 30_000)
    {
        var wd = Path.GetDirectoryName(AdbExePath)!;
        var args = Regex.Matches(arguments, "\"([^\"]*)\"|\\S+")
                        .Select(m => m.Value.Trim('"'))
                        .ToList();

        var r = ProcessExec.Run(AdbExePath, args, wd, timeoutMs);
        if (r.ExitCode != 0)
            throw new AdbCommandException("adb failed", r.ExitCode, r.StdOut, r.StdErr);

        return r.StdOut?.Trim() ?? "";
    }

    private string RunArgs(IReadOnlyList<string> args, int timeoutMs)
    {
        var wd = Path.GetDirectoryName(AdbExePath)!;
        var r = ProcessExec.Run(AdbExePath, args, wd, timeoutMs);

        if (r.ExitCode != 0)
            throw new AdbCommandException("adb failed", r.ExitCode, r.StdOut, r.StdErr);

        return r.StdOut?.Trim() ?? "";
    }

    public async Task WaitForDeviceReadyAsync(string serial, CancellationToken ct)
    {
        var deadline = DateTime.UtcNow.AddMilliseconds(_opt.DeviceWaitTimeoutMs);

        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            var d = Devices().FirstOrDefault(x => x.Serial == serial);
            if (d?.State == "device")
                return;

            await Task.Delay(_opt.DevicePollIntervalMs, ct);
        }

        throw new AdbDeviceNotFoundException($"Device not ready: {serial}");
    }

    public void StartPackageMonkey(string serial, string packageName, int timeoutMs = 30_000)
        => _ = Shell(serial, $"monkey -p {packageName} 1", timeoutMs);

    public void ForceStopPackage(string serial, string packageName, int timeoutMs = 30_000)
        => _ = Shell(serial, $"am force-stop {packageName}", timeoutMs);

    public bool IsPackageRunning(string serial, string packageName, int timeoutMs = 15_000)
    {
        try
        {
            return !string.IsNullOrWhiteSpace(
                Shell(serial, $"pidof {packageName}", timeoutMs));
        }
        catch { return false; }
    }

    public void StartActivity(string serial, string component, int timeoutMs = 30_000)
        => _ = Shell(serial,
            $"am start -n {component} -a android.intent.action.MAIN -c android.intent.category.LAUNCHER",
            timeoutMs);

    public string GetTopActivity(string serial, int timeoutMs = 30_000)
    {
        var txt = Shell(serial, "dumpsys window windows", timeoutMs);
        var idx = txt.IndexOf("mCurrentFocus", StringComparison.OrdinalIgnoreCase);
        return idx > 0 ? txt.Substring(idx, Math.Min(200, txt.Length - idx)) : txt;
    }

    // ============================================================
    // Screenshot
    // ============================================================
    public byte[] ScreenshotPng(string serial, int timeoutMs = 30_000)
    {
        var tmp = Path.Combine(Path.GetTempPath(), $"sf_shot_{Guid.NewGuid():N}.png");
        var remote = "/sdcard/__sf_shot.png";

        try
        {
            Shell(serial, $"rm -f {remote}", timeoutMs);
            Shell(serial, $"screencap -p {remote}", timeoutMs);
            RunArgs(new[] { "-s", serial, "pull", remote, tmp }, timeoutMs);
            return File.ReadAllBytes(tmp);
        }
        finally
        {
            try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
        }
    }

    private static IReadOnlyList<AdbDevice> ParseDevices(string text)
    {
        var list = new List<AdbDevice>();
        if (string.IsNullOrWhiteSpace(text)) return list;

        foreach (var raw in text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
        {
            var line = raw.Trim();
            if (line.StartsWith("List of devices") || line.StartsWith("*"))
                continue;

            var parts = Regex.Split(line, @"\s+");
            if (parts.Length >= 2)
                list.Add(new AdbDevice(parts[0], parts[1]));
        }

        return list;
    }
}
