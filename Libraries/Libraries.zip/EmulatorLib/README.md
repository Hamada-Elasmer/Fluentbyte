# EmulatorLib

A small library that wraps *emulator discovery and metadata*.

## Current support
- **MEmu** (Windows)

## Important note (SparkFlow v1)
SparkFlow's execution pipeline is **ADB-first** and **emulator-agnostic**:
- SparkFlow does **not** infer device endpoints from emulator-specific CLIs.
- Every profile must persist its **explicit ADB serial** (Owner ADB is the source of truth).
- All device commands are executed as: `adb -s {serial} ...`

EmulatorLib is kept for optional UX features (listing instances, opening folders, etc.), but **the runner must not depend on it**.