﻿namespace EmulatorLib.LDPlayer;

public static class LDPlayerPaths
{
    // Some installs use dnconsole.exe, others use ldconsole.exe
    public const string DnConsoleExe = "dnconsole.exe";
    public const string LdConsoleExe = "ldconsole.exe";

    public static readonly string[] CandidateConsoleExes =
    {
        DnConsoleExe,
        LdConsoleExe
    };

    public static readonly string[] CommonRoots =
    {
        @"C:\Program Files\LDPlayer\LDPlayer9",
        @"C:\Program Files (x86)\LDPlayer\LDPlayer9",
        @"C:\LDPlayer\LDPlayer9",
        @"D:\LDPlayer\LDPlayer9"
    };
}
