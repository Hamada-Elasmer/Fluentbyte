﻿/* ============================================================================
 * SparkFlow File Header
 * File: Libraries/EmulatorLib/LDPlayer/LDPlayerInstance.cs
 * Purpose: Emulator instance: LDPlayerInstance.
 * Notes:
 *  - Implements IEmulatorInstance : IAdbPortProvider exactly as defined in Fluentbyte.
 * ============================================================================ */

using System.Runtime.Versioning;

using EmulatorLib.Abstractions;
using EmulatorLib.Models;

namespace EmulatorLib.LDPlayer;

[SupportedOSPlatform("windows")]
public sealed class LDPlayerInstance : IEmulatorInstance, IAdbPortProvider
{
    private readonly LDPlayerCli _cli;
    private readonly EmulatorInstanceInfo _info;

    public LDPlayerInstance(LDPlayerCli cli, EmulatorInstanceInfo info)
    {
        _cli = cli ?? throw new ArgumentNullException(nameof(cli));
        _info = info ?? throw new ArgumentNullException(nameof(info));
    }

    public string InstanceId => _info.InstanceId;
    public string Name => _info.Name;

    public EmulatorState State => _info.State;

    // ✅ FIX: If list2 didn't provide a valid port, derive a stable fallback:
    // instanceId "1" -> 5554, "2" -> 5556, "3" -> 5558 ... (Android emulator pattern)
    public int? AdbPort
    {
        get
        {
            if (_info.AdbPort is int p && p >= 5554)
                return p;

            var n = TryParseInstanceNumber(_info.InstanceId);
            if (n > 0)
                return 5554 + (n * 2);

            return null;
        }
    }

    public void Start() => _cli.Launch(InstanceId);

    public void Stop() => _cli.Quit(InstanceId);

    public async Task WaitUntilOnlineAsync(CancellationToken ct)
    {
        // Minimal, deterministic wait loop (LDPlayer list2 port is best-effort).
        // You can enhance later by verifying adb readiness using AdbLib from Core.
        if (AdbPort is null)
            throw new InvalidOperationException("ADB port missing for this instance (list2 did not provide a valid port and fallback failed).");

        var deadline = DateTime.UtcNow.AddSeconds(60);

        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            await Task.Delay(500, ct).ConfigureAwait(false);
        }
    }

    private static int TryParseInstanceNumber(string? instanceId)
    {
        if (string.IsNullOrWhiteSpace(instanceId))
            return -1;

        instanceId = instanceId.Trim();

        // Fast path: numeric instanceId ("1", "2", ...)
        if (int.TryParse(instanceId, out var n) && n > 0)
            return n;

        // Best-effort: extract trailing digits (e.g., "leidian3" -> 3)
        var i = instanceId.Length - 1;
        while (i >= 0 && char.IsDigit(instanceId[i])) i--;

        var digits = instanceId[(i + 1)..];
        return (int.TryParse(digits, out var t) && t > 0) ? t : -1;
    }
}
