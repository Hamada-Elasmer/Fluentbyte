﻿namespace EmulatorLib.Abstractions;

public interface IAdbPortProvider
{
    int? AdbPort { get; }
}
